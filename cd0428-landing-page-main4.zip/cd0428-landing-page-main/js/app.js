/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/
const navbarList = document.getElementById('navbar__list');  // grabs navbar ul
const sections = document.querySelectorAll('section');  // grabs all section elements
const navLinks = document.querySelectorAll('.menu__link');  // grabs all nav links

const section1 = document.getElementById('section1')

// build the nav

for (let i = 0; i < sections.length; i++) {
    const section = sections[i];  // current section
    const id = section.id;  // current section id
    const title = section.getAttribute('data-nav');  // current section title
    const li = document.createElement('li');  // creates new li element
    const a = document.createElement('a');  // creates new anchor element

    a.textContent = title;  // sets text content of anchor to current section title 
    a.setAttribute('href', `#${id}`);  // sets href of anchor to current sention id
    a.className = "menu__link";  // sets anchor class
    a.setAttribute('id', `link${id}`)

  // click event handler
    a.addEventListener('click', (e) => {  // takes two arguments, event to listen for and function to run on the event 
        e.preventDefault(); // prevents default behaviour of click
        
    // scrolls section into viewport 
    section.scrollIntoView({ 
            behavior: 'smooth',  // sets transition to smooth
        });
    });

    li.append(a);  // appends anchor to current section
    navbarList.appendChild(li);  // all appends current section to navbar ul
}

// Add class 'active' to section when near top of viewport



// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active

const options = {
  threshold: 0.75
};

const observer = new IntersectionObserver(
  function(entries, observer) {
    entries.forEach((entry) => {
      const section = entry.target;
      const sectionId = section.id;
      const link = navbarList.querySelector(`#link${sectionId}`);

      if (entry.isIntersecting) {
        section.classList.add('active'); 
        link.classList.add('active'); 
      } else {
        section.classList.remove('active'); 
        link.classList.remove('active'); 
      }
    });
  },
  options
);

sections.forEach((section) => {
  observer.observe(section);
});
